import { Component } from '@angular/core';

@Component({
  selector: 'lazy-two',
  template: `
    <h2 class="text-success">Lazy Two Component from Lazy Module Loaded...</h2>
  `
})
export class LazyTwoComponent { }
