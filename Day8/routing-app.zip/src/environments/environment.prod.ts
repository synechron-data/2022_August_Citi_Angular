export const environment = {
  production: true,
  usersUrl: 'http://www.synechron.com/api/users'
};
