import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html'
})
export class ListComponent implements OnInit {
  @Input() personList?: Array<string>;
  selected: string;
  by: string;

  constructor() {
    this.selected = "";
    this.by = "";
  }

  ngOnInit(): void {
  }

  select(p: string, e: Event) {
    e.preventDefault();
    this.selected = p;
  }
}
