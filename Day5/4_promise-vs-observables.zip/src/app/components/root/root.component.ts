import { Component } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent {
  obSub?: Subscription;

  constructor() {
    // this.getPromise();
    // this.getObservable();

    // --------------------------------------------------
    // this.getPromise().then(data => {
    //   console.log(`Promise Output - ${data}`);
    // }).catch(err => {
    //   console.error(`Promise Error - ${err}`);
    // });

    // this.obSub = this.getObservable().subscribe({
    //   next: data => {
    //     console.log(`Observable Output - ${data}`);
    //   }, error: err => {
    //     console.error(`Observable Error - ${err}`);
    //   }
    // });

    // setTimeout(() => {
    //   this.obSub?.unsubscribe();
    // }, 9000);

    // // -------------------------------------------------- Observables are single-cast
    // var ob1 = this.getObservable();

    // ob1.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 1, Output - ${data}`);
    //   }, error: err => {
    //     console.error(`Subscriber 1, Error - ${err}`);
    //   }
    // });

    // ob1.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 2, Output - ${data}`);
    //   }, error: err => {
    //     console.error(`Subscriber 2, Error - ${err}`);
    //   }
    // });

    // -------------------------------------------------- Subjects are multi-cast
    //   var s = this.getSubject();

    //   s.subscribe({
    //     next: data => {
    //       console.log(`Subscriber 1, Output - ${data}`);
    //     }, error: err => {
    //       console.error(`Subscriber 1, Error - ${err}`);
    //     }
    //   });

    //   s.subscribe({
    //     next: data => {
    //       console.log(`Subscriber 2, Output - ${data}`);
    //     }, error: err => {
    //       console.error(`Subscriber 2, Error - ${err}`);
    //     }
    //   });
    // }

    // -------------------------------------------------- Subjects as multi-cast observable
    // var s = this.getSubjectAsObservable();

    // s.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 1, Output - ${data}`);
    //   }, error: err => {
    //     console.error(`Subscriber 1, Error - ${err}`);
    //   }
    // });

    // s.subscribe({
    //   next: data => {
    //     console.log(`Subscriber 2, Output - ${data}`);
    //   }, error: err => {
    //     console.error(`Subscriber 2, Error - ${err}`);
    //   }
    // });
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 4000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 4000);

    return s;
  }

  getObservable(): Observable<number> {
    return new Observable((ob) => {
      // Any Async Code
      setInterval(function () {
        // console.log("Observable - Set Interval Executed...");
        ob.next(Math.random());
      }, 4000);
    });
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      // Any Async Code
      setInterval(function () {
        // console.log("Promise - Set Interval Executed...");
        resolve(Math.random());
      }, 4000);
    });
  }
}