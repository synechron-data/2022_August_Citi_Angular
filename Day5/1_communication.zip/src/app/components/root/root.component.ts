import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CounterComponent } from '../counter/counter.component';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent {
  pList: Array<string>;
  message: string;

  @ViewChild("c1", { static: true })
  counter_one?: CounterComponent;

  @ViewChild("c2", { static: true })
  counter_two?: CounterComponent;

  @ViewChildren(CounterComponent)
  counters?: QueryList<CounterComponent>;

  constructor() {
    this.pList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh", "Pravin"];
    this.message = "";
  }

  p2_reset(c: CounterComponent) {
    c.reset();
  }

  p3_reset() {
    if (this.counter_one)
      this.counter_one.reset();

    this.counter_two?.reset();
  }

  reset_all() {
    if (this.counters) {
      for (const counter of this.counters) {
        counter.reset();
      }
    }
  }

  updateMessage(flag: boolean) {
    if (flag)
      this.message = "Max Click Reached, please Reset to restart";
    else
      this.message = "";
  }
}