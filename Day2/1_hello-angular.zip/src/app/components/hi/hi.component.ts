import { Component } from '@angular/core';

@Component({
  selector: 'app-hi',
  template: `
    <h1>
      Hi World!
    </h1>
  `
})
export class HiComponent { }
