import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManishLibAug22Component } from './manish-lib-aug22.component';

describe('ManishLibAug22Component', () => {
  let component: ManishLibAug22Component;
  let fixture: ComponentFixture<ManishLibAug22Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManishLibAug22Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManishLibAug22Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
