import { TestBed } from '@angular/core/testing';

import { ManishLibAug22Service } from './manish-lib-aug22.service';

describe('ManishLibAug22Service', () => {
  let service: ManishLibAug22Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManishLibAug22Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
