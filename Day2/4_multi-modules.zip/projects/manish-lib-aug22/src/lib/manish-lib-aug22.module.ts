import { NgModule } from '@angular/core';
import { ManishLibAug22Component } from './manish-lib-aug22.component';



@NgModule({
  declarations: [
    ManishLibAug22Component
  ],
  imports: [
  ],
  exports: [
    ManishLibAug22Component
  ]
})
export class ManishLibAug22Module { }
