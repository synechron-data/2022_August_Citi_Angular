/*
 * Public API Surface of manish-lib-aug22
 */

export * from './lib/manish-lib-aug22.service';
export * from './lib/manish-lib-aug22.component';
export * from './lib/manish-lib-aug22.module';
