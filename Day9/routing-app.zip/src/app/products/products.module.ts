import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsRootComponent } from './components/products-root/products-root.component';
import { ProductsNotSelectedComponent } from './components/products-not-selected/products-not-selected.component';
import { ProductsDetailsComponent } from './components/products-details/products-details.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    ProductsRootComponent,
    ProductsNotSelectedComponent,
    ProductsDetailsComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    ProductsRootComponent,
    ProductsNotSelectedComponent,
    ProductsDetailsComponent
  ]
})
export class ProductsModule { }
