import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'admin',
  templateUrl: './admin.component.html'
})
export class AdminComponent implements OnInit, OnDestroy {
  message: string;
  users?: Array<any>;
  gu_sub?: Subscription;

  constructor(private usersService: UsersService) {
    this.message = "Loading data, please wait...";
  }

  ngOnInit(): void {
    this.gu_sub = this.usersService.getAllUsers().subscribe(resData => {
      this.users = resData;
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

  ngOnDestroy(): void {
    this.gu_sub?.unsubscribe();
  }
}
