export const environment = {
  production: true,
  postsUrl: 'https://www.synechron.com/posts',
  usersUrl: 'https://www.synechron.com/users'
};
