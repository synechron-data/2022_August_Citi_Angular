import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  providers: [UserService]
})
export class UserComponent implements OnInit, OnDestroy {
  users?: Array<any>;
  selectedUser?: any;
  flag: boolean;
  message?: string;
  get_sub?: Subscription;
  get_user_sub?: Subscription;
  sUserId: string;

  constructor(private userService: UserService) {
    this.flag = true;
    this.sUserId = "";
  }

  ngOnInit(): void {
    this.get_sub = this.userService.getAllUsers().subscribe({
      next: resData => {
        this.users = [...resData];
        this.message = "";
        this.flag = false;
      }, error: (err: string) => {
        this.message = err;
      }
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
  }

  getUserDetails(id: string) {
    this.get_user_sub = this.userService.getUser(id).subscribe({
      next: resData => {
        this.selectedUser = resData;
        console.log(this.selectedUser);
      }, error: (err: string) => {
        this.message = err;
      }
    });
  }
}
