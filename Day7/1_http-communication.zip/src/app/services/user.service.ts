import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, delay, mergeMap, Observable, retry, throwError } from "rxjs";
import { environment } from "src/environments/environment";

@Injectable()
export class UserService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = environment.usersUrl;
    }

    getAllUsers() {
        return this.httpClient.get<Array<any>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getAllUsers', []))
        );
    }

    // getUser(id:number) {
    //     let userSpecificUrl = `${this.url}/${id}`;
    //     return this.httpClient.get<any>(userSpecificUrl);
    // }

    getUserMS(id: string) {
        let userSpecificUrl = `${this.url}/${id}`;
        return this.httpClient.get<any>(userSpecificUrl).subscribe(user => {
            this.httpClient.get<any>(user.id).subscribe(posts => {
                user.posts = posts;
            });
        })
    }

    getUser(id: string) {
        let userSpecificUrl = `${this.url}/${id}`;
        return this.httpClient.get<any>(userSpecificUrl).pipe(
            mergeMap(user => this.getUserPosts(user.id)),
            catchError(this._handleError('getUser', []))
        );
    }

    getUserPosts(id: string) {
        let postsSpecificUserUrl = `${this.url}/${id}/posts`;
        return this.httpClient.get<any>(postsSpecificUserUrl);
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.log(`${operation} failed: ${err.message}`);
            return throwError(() => 'Connection Error, please try again later...');
        }
    }
}