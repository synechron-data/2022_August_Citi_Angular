import { AuthorsService } from "./authors.service";
import { NAuthorsService } from "./nauthors.service";

export function AuthorFactory(enviorment: any) {
    if (enviorment["production"])
        return new NAuthorsService();
    else
        return new AuthorsService();
}