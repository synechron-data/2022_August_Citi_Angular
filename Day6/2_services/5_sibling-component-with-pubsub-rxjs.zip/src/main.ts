import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));

// ------------------------------------------------

// class Employee {
//   private _name: string;

//   constructor(name: string) {
//     this._name = name;
//   }

//   getName() {
//     return this._name;
//   }

//   setName(value: string) {
//     this._name = value;
//   }
// }

// let e = new Employee("Manish");
// console.log(e.getName());
// e.setName("Abhijeet");
// console.log(e.getName());


// -------------------------- Property
// class Employee {
//   private _name: string;

//   constructor(name: string) {
//     this._name = name;
//   }

//   get Name() {
//     return this._name;
//   }

//   set Name(value: string) {
//     this._name = value;
//   }
// }

// let e = new Employee("Manish");
// console.log(e.Name);
// e.Name = "Abhijeet";
// console.log(e.Name);