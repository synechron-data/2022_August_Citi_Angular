import { Component } from '@angular/core';
import { AuthorsService } from 'src/app/services/authors.service';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html',
    providers: [AuthorsService]
})
export class RootComponent { }