import { Component, Input, NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { By } from "@angular/platform-browser";
import { of } from "rxjs";
import { Hero } from "src/app/models/hero";
import { HeroService } from "src/app/services/hero.service";
import { HeroesComponent } from "./heroes.component";

describe('HerosComponent (Shallow Tests)', () => {
    let fixture: ComponentFixture<HeroesComponent>;
    let HEROES: Array<Hero>;
    let mockHeroService: any;

    @Component({
        selector: 'app-hero',
        template: '<div></div>'
    })
    class FakeHeroComponent {
        @Input() hero!: Hero;
    }

    beforeEach(() => {
        HEROES = [
            { id: 1, name: 'Spider Man', strength: 8 },
            { id: 2, name: 'Wonder Woman', strength: 24 },
            { id: 3, name: 'Super Man', strength: 55 }
        ];

        mockHeroService = jasmine.createSpyObj(['getHeroes', 'addHeroes', 'deleteHero']);

        TestBed.configureTestingModule({
            declarations: [
                HeroesComponent,
                FakeHeroComponent
            ],
            providers: [
                { provide: HeroService, useValue: mockHeroService }
            ],
            // schemas: [
            //     NO_ERRORS_SCHEMA
            // ]
        });

        fixture = TestBed.createComponent(HeroesComponent);
    });

    it('should set heroes correctly from the service', () => {
        mockHeroService.getHeroes.and.returnValue(of(HEROES));
        fixture.detectChanges();

        expect(fixture.componentInstance.heroes.length).toBe(3);
    });

    it('should create one li for each hero', () => {
        mockHeroService.getHeroes.and.returnValue(of(HEROES));
        fixture.detectChanges();

        expect(fixture.debugElement.queryAll(By.css('li')).length).toBe(3);
    });
});