import { of } from "rxjs";
import { Hero } from "src/app/models/hero";
import { HeroesComponent } from "./heroes.component";

describe('HerosComponent', () => {
    let component: HeroesComponent;
    let HEROES: Array<Hero>;
    let mockHeroService: any;

    beforeEach(() => {
        HEROES = [
            { id: 1, name: 'Spider Man', strength: 8 },
            { id: 2, name: 'Wonder Woman', strength: 24 },
            { id: 3, name: 'Super Man', strength: 55 }
        ];

        mockHeroService = jasmine.createSpyObj(['getHeros', 'addHeros', 'deleteHero']);

        component = new HeroesComponent(mockHeroService);
    });

    describe('delete', () => {
        it('should remove the specified hero from the heroes list', () => {
            mockHeroService.deleteHero.and.returnValue(of(true));
            component.heroes = HEROES;

            component.delete(HEROES[2]);

            expect(component.heroes.length).toBe(2);
        });

        it('should call deleteHero from the service', () => {
            mockHeroService.deleteHero.and.returnValue(of(true));
            component.heroes = HEROES;

            component.delete(HEROES[2]);

            // expect(mockHeroService.deleteHero).toHaveBeenCalled();
            expect(mockHeroService.deleteHero).toHaveBeenCalledWith(HEROES[2]);
        });
    })
});