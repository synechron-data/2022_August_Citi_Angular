describe('my first test', () => {
    let sut: any;       // System Under Test

    beforeEach(() => {
        sut = {};
    });

    it('should be true if true', () => {
        // arrange
        // sut = {};
        sut.a = false;

        // act
        sut.a = true;

        // assert
        expect(sut.a).toBe(true);
    });
});